<div class="header">
    	<div class="logo">
        <a href="index.php"><img width="100" height="60" src="images/logo.jpg" alt="Book Bird" /></a>
        </div><!--logo ends-->
		<div class="navigation">
		<p>
        <?php 
			include("categorylist.php");
		?>
        <a href="login.php">Admin</a>
        </p>
      </div><!--navigation ends-->
	</div><!-- Header ends here-->
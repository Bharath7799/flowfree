<?php
	session_start();
	// check to see if user is logged in. If not, redirect to admin page
	if(!isset($_SESSION['admin'])) {
		header("Location:index.php?page=admin");
	}
?>
<h1>delete new Book</h1>
<form method="post" action="index.php?page=deletedocument" />
<!-- <datalist id="books">=-->
<?php
$stock_sql="SELECT * FROM stock ";
	if($stock_query=mysqli_query($dbconnect, $stock_sql)) {
		$stock_rs=mysqli_fetch_assoc($stock_query);
	}
	if(mysqli_num_rows($stock_query)==0) {
		echo "Sorry, we have no items currently in stock";
	} else {
		?>
		
<h1><?php //echo $stock_rs['catname']; ?></h1>
		<?php do {
			?>
			<div >
			<a href="index.php?page=item&stock_id=<?php echo $stock_rs['stock_id']; ?>">
			<img width="100" height="50" src="images/<?php echo $stock_rs['thumbnail']; ?>" alt="book"	?>
			<p><?php echo $stock_rs['name']; ?></p>
			<p> BY <?php echo $stock_rs['description']; ?></p>
			<p>Rs.<?php echo $stock_rs['price']; ?></p>
			
			</a>
			</div>
		<?php
		} while ($stock_rs=mysqli_fetch_assoc($stock_query));
		?>
<?php
	}
	?>



<?php
/*
$cat_sql="SELECT * FROM stock";
			$cat_query=mysqli_query($dbconnect, $cat_sql);
			$cat_rs=mysqli_fetch_assoc($cat_query);
		
			do { ?>
			<a href="index.php?page=category&cat_id=<?php echo $cat_rs['stock_id']; ?>"><?php echo $cat_rs['name']; ?></a>
				
				<?php
			} while ($cat_rs=mysqli_fetch_assoc($cat_query))

*/
?>


<p><input type="submit" name="submit" value="delete Book" /></p>

</form>

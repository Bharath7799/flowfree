<div class="header">
    	<div class="logo">
        <a href="index.php"><p><b><font size="4" color="#100000">
     BookBird</b></a>
        </div><!--logo ends-->



<h1>Login</h1>
<head>
	<meta charset="UTF-8">

  <title>Forgot password screen</title>
    
   
  <link rel="stylesheet" href="stylelogin.css">
</head>
<body>
<div class="wrapper">
<div class="container">


</body>
 <form name ="login" class="form" action="index.php?page=admin" method="post">
        <input type="text" name="username" placeholder="username" /><br />
        <input type="password" name="password"  placeholder="password"/><br/>
        

        
        <!-- 
       <button type="submit" name="login" value="Submit"  class="btn btn-primary btn-block btn-large">GO...</button>
   		 -->
       <?php 
		if(isset($_POST['login']) && !isset($_SESSION['admin'])) {
		?>
		<p><span class="error">Incorrect username or password</span></p>
		<?php
	}
	?>

	<input type="submit" name="login" value="Login " />
    </form>
<!-- 
<form name="login" method="post" action="index.php?page=admin">
<p>Username <input name="username" type="text" maxlength=30 /></p>
<p>Password <input name="password" type="password" maxlength=30  /></p> -->


<!--<p><input type="submit" name="login" value="Submit" /></p>
</form>-->
<a href="forgotpass.php"><p><b><font size="4" color="#100000">
          Forgot Password</b></a></a>
          <a href="login3.php"><p><b><font size="4" color="#100000">
     Sign Up</b></a></a>
</div>
</div>

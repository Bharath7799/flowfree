<?php
	// If categoryID is not set, redirect back to index page
	if(!isset($_GET['cat_id'])) {
		header("Location:index.php");
	}
	// Select all stock items belonging to the selected categoryID
	$stock_sql="SELECT stock.stock_id, stock.name, stock.price,stock.thumbnail,stock.description, category.cat_name AS catname FROM stock JOIN category ON stock.cat_id=category.cat_id WHERE stock.cat_id=".$_GET['cat_id'];
	if($stock_query=mysqli_query($dbconnect, $stock_sql)) {
		$stock_rs=mysqli_fetch_assoc($stock_query);
	}
	if(mysqli_num_rows($stock_query)==0) {
		echo "Sorry, we have no items currently in stock";
	} else {
		?>
		<h1><?php echo $stock_rs['catname']; ?></h1>
		<?php do {
			?>
			<div class="item">
			<a href="index.php?page=item&stock_id=<?php echo $stock_rs['stock_id']; ?>">
			<img width="100" height="50" src="images/<?php echo $stock_rs['thumbnail']; ?>" alt="book"	?>
			<p><?php echo $stock_rs['name']; ?></p>
			<p> BY <?php echo $stock_rs['description']; ?></p>
			<p>Rs.<?php echo $stock_rs['price']; ?></p>
			
			</a>
			</div>
		<?php
		} while ($stock_rs=mysqli_fetch_assoc($stock_query));
		?>
	<?php
	}
	?>
<?php
//This file is the base for all pages in the site. When creating a new page, we just open this one, then save a copy as the new page.
  include("dbconnect.php");
?>
<html>
<head>
<title>Welcome to the ocean of BOOKS</title>
<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <link href="styles.css" rel="stylesheet" type="text/css" />
      <script type="text/javascript" src="js/jquery.min.js"></script> 
      <script type="text/javascript" src="materialize/js/materialize.min.js"></script>
      <script type="text/javascript">
        $(document).ready(function(){
           $('.slider').slider({full_width: true});
        });
      </script>
</head>

<body>
<div class="container">
  <?php
    include("header1.php");
    // check to see if user is visiting a page other than the home page
    if(!isset($_GET['page'])) { ?>
    <!--<div class="banner"><img width="1000" height="500"src="images/banner.jpg" alt="book bird" /></div> -->

    <div class="slider">
    <ul class="slides">
      <li>
        <img width="1000" height="500" src="images/banner1.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3>Books are uniquely portable MAGIC!</h3>
          <h5 class="light grey-text text-lighten-3">.</h5>
       
      </li>
      <li>
        <img width="1000" height="500" src="images/banner2.jpg"> <!-- random image -->
        <div class="caption left-align">
          <h3>No two persons ever read the same book...</h3>
          <h5 class="light grey-text text-lighten-3">.</h5>
       
      </li>
      <li>
        <img width="1000" height="500" src="images/banner3.jpg"> <!-- random image -->
        <div class="caption right-align">
          <h3>Drink good COFFEE and read good BOOKS.</h3>
          <h5 class="light grey-text text-lighten-3">.</h5>
        
      </li>
      <li>
      <img width="1000" height="500" src="images/banner4.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3>A reader lives a thousand lives before he dies...</h3>
         <h5 class="light grey-text text-lighten-3">.</h5>
      
      </li>
    </ul>
  </div>
      





    <?php
  }
  
  ?>
  
    <div class="maincontent">
    <?php 
      if(!isset($_GET['page'])) {
        include("home.php");
      } else {
        ?>
         <?php
        $page=$_GET['page'];
        include("$page.php");
      }
    ?>
  </div>
    <?php
    include("seccontent.php");
  ?>

  <div class="footer"></div>
</div><!-- Container ends here-->
</body>
</html>

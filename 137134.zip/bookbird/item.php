<?php
	// redirect back to index page if no stockID has been set
	if(!isset($_GET['stock_id'])) {
		header("Location: index.php");
	}
	$item_sql="SELECT * FROM stock WHERE stock_id=".$_GET['stock_id'];
	if($item_query=mysqli_query($dbconnect, $item_sql)) {
		$item_rs=mysqli_fetch_assoc($item_query);
		?>
		<img width="900" height="500" src="images/<?php echo $item_rs['thumbnail']; ?>" alt="book"	?>
		<h1><?php echo $item_rs['name']; ?></h1>
		<p>$<?php echo $item_rs['price']; ?></p>
		<p><?php echo $item_rs['description']; ?></p>
		<p><?php echo $item_rs['thumbnail']; ?></p>
		<?php
	}
?>
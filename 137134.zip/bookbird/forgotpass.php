<!DOCTYPE html>
<html >
  
<head>
    <meta charset="UTF-8">

  <title>Forgot password screen</title>
    
   
  <link rel="stylesheet" href="stylelogin.css">

    
    

 </head>

  <body>

    <div class="wrapper">
<div class="container">
	
<h1>BookBird</h1>
 <?php

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','bharath');
define('DB_NAME','books');

if (!isset($_POST['submit'])){
?>
<!-- The HTML login form -->
     
     <form class="form" action="<?=$_SERVER['PHP_SELF']?>" method="post">
        <input type="text" name="username" placeholder="username" /><br />
        

        <input type="submit" name="submit" value="Submit " />
       
    </form>

<?php
} 
else {
    require_once("dbconnect.php");
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    # check connection
    if ($mysqli->connect_errno) {
        echo "<p>MySQL error no {$mysqli->connect_errno} : {$mysqli->connect_error}</p>";
        exit();
    }
   // $sql="SELECT user.password as pass FROM user WHERE user.username LIKE '{$username}'";
    //$result = $mysqli->query($sql);
    $username = $_POST['username'];
    //echo $username;
    //$username1=$_GET['username'];
        $from= "bharath.manthati@gmail.com";
        $subject="BookBird password recovery";
    $sql = "SELECT user.username from user WHERE user.username LIKE '".$username."'";
    $result = $mysqli->query($sql);
      if ($result->num_rows == 1) {
        $row=$result->fetch_assoc();
       $sql="SELECT password from user where user.username LIKE '".$username."'";
       $result= $mysqli->query($sql);
       $row=$result->fetch_assoc();
      // $pass = print_r($row['password']);
       $pass1=$row['password'];
       $sql="SELECT email from user where user.username LIKE '".$username."'";
       $to= $mysqli->query($sql);
       //var_dump($to->fetch_assoc()['email']);
       $from="BookBird";
       $url="http://localhost/try2/login.php";
       
       $b1="".'</br>'.'-------------------------------------------'.'</br> Username:'.$username.' </br>Email: '.$to->fetch_assoc()['email'].'</br>Here is your new password :'.$pass1.'</br>';
        
        
        
       $b2="Please Login and change password of the account immediately.";
        $body=$b1." ".$b2;
        echo $subject .'</br>';
        echo $body;
        $sentmail = mail($to->fetch_assoc()['email'],$subject,$body);

        }
      else
{
   echo "Email Not found for the username!";
}

if($sentemail==1)
{
    echo "Your password has been sent to your email address!";    
}
else
{   echo "Cannot send password to your email address. Problem with sending email...";
}
   
}
?>      
</div>
   
    
    
 
 </body>
</html>

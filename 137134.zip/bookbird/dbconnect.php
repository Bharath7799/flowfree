<?php

/*
        $host ='localhost';
		$user = 'root';
		$pass = 'bharath';
		$dbname = 'books';
		$dbconnect = new mysqli($host, $user, $pass, $dbname);
		if($dbconnect->connect_error) {
			die('Could not connect to database');
		}
		$sql = 'SELECT * FROM users where rno like "%'.$rno.'%"';
		$res = $conn->query($sql);
		if($res->num_rows > 0) {
			$result = true;
		}




*/


	$dbconnect = mysqli_connect("localhost", "root", "bharath", "books");
	if(mysqli_connect_errno()) {
		echo "Connection failed:".mysqli_connect_error();
		exit;
	}

?>
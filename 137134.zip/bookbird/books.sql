-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2015 at 12:15 AM
-- Server version: 5.5.44-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `books`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(1) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(25) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(1, 'education'),
(2, 'novels'),
(3, 'devotional'),
(4, 'inspirational'),
(5, 'science');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `stock_id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `cat_id` int(1) NOT NULL,
  `price` float(5,2) NOT NULL,
  `thumbnail` varchar(30) NOT NULL,
  `bigphoto` varchar(30) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock_id`, `name`, `cat_id`, `price`, `thumbnail`, `bigphoto`, `description`) VALUES
(1, 'Democracy and Education', 1, 999.00, 'educational1.jpg', '', 'John Dewey'),
(2, 'Education and Technology', 1, 499.00, 'educational2.jpg', '', 'Ann Kovalchick'),
(3, 'SAT Subject Test', 1, 699.00, 'educational3.jpg', '', 'Barrons'),
(4, 'Education and Technology', 1, 699.00, 'educational4.jpg', '', 'Timothy J. Newby'),
(5, 'The DA VINCI CODE', 2, 999.99, 'novel1.jpg', '', 'Dan Brown'),
(6, 'THE ALCHEMIST', 2, 999.99, 'novel2.jpg', '', 'Paulo Coelho'),
(7, 'City Of Bones', 2, 999.99, 'novel3.jpg', '', 'Cassandra Clare'),
(8, 'Dead Until Dark', 2, 999.99, 'novel4.jpg', '', 'Charlaine Harris'),
(9, 'The Mahabharata', 3, 999.99, 'devotional1.jpg', '', 'Shriji Dasa'),
(10, 'The Oath Of The Vayuputras', 3, 999.99, 'devotional2.jpg', '', 'Amish'),
(11, 'The Holy Bible', 3, 999.99, 'devotional3.jpg', '', 'jesus'),
(12, 'The Quran', 3, 999.99, 'devotional4.jpg', '', 'GOD'),
(13, 'Living At The Source', 4, 999.99, 'inspirational1.jpg', '', 'Vivekananda'),
(14, 'I Know Why The Caged Bird Sings', 4, 999.99, 'inspirational2.jpg', '', 'Maya Angelou'),
(15, 'The Secret', 4, 999.99, 'inspirational3.jpg', '', 'Rhonda Byine'),
(16, 'The Shack', 4, 999.99, 'inspirational4.jpg', '', 'WM. Paul Young'),
(17, 'Extreme Science Friction', 5, 999.99, 'science1.jpg', '', 'Mike Ashley'),
(18, 'THE CHRONICLES OF "NARNIA"', 5, 999.99, 'science2.jpg', '', 'CS. Lewis'),
(19, 'The Stone Gods', 5, 999.99, 'science3.jpg', '', 'Jeanette Winterson'),
(20, 'Science Friction', 5, 999.99, 'science4.jpg', '', 'Damien Broderick');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(20) NOT NULL,
  `password` int(10) NOT NULL,
  `email` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `gender` varchar(256) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `email`, `name`, `gender`) VALUES
('admin1', 12345, 'anichavan20@gmail.com', '', ''),
('admin2', 0, 'bharath.manthati@gmail.com', 'bharath', 'm');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

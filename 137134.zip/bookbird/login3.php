<!DOCTYPE html>
<html >
  
<head>
    <meta charset="UTF-8">

  <title>signup</title>
    
   
  <link rel="stylesheet" href="stylelogin.css">

    
    

 </head>

  <body>

    <div class="wrapper">
<div class="container">
	
<h1>Signup</h1>
		
	
			

 	
	
 <?php

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','bharath');
define('DB_NAME','books');

if (!isset($_POST['submit'])){
?>
<!-- The HTML login form -->
     <div class="scroller">
     <form class="form" action="<?=$_SERVER['PHP_SELF']?>" method="post">
        <input type="text" name="username" placeholder="username" /><br />
        <input type="password" name="password" placeholder="password" /><br />
 <!--  <input type="regno" name="regno" placeholder="regno" /><br />
  -->
 <input type="name" name="name" placeholder="Full name" /><br />
 <input type="gender" name="gender" placeholder="Gender(F/M)" /><br />
 <!-- <input type="dob" name="dob" placeholder="DOB" /><br /> -->
        <!-- <input type="branch" name="branch" placeholder="Branch" /><br /> -->
         <input type="email" name="email" placeholder="Email id" /><br />
<!-- <input type="phone" name="phone" placeholder="PhoneNumber" /><br /> -->
<!-- <input type="pname" name="pname" placeholder="Parent/gaurdian name" /><br /> -->
 <!-- <input type="pphone" name="pphone" placeholder="Phone" /><br /> -->
 
<input type="submit" name="submit" value="  signup  " />

    </form>
</div>
<?php
} else {
    //require_once("db_const.php");
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    # check connection
    if ($mysqli->connect_errno) {
        echo "<p>MySQL error no {$mysqli->connect_errno} : {$mysqli->connect_error}</p>";
        exit();
    }
    $sql="delete from curruser";
    $result = $mysqli->query($sql);
    $username = $_POST['username'];
    $password = $_POST['password'];
 //$regno = $_POST['regno'];
 $name=$_POST['name'];
	//$pname=$_POST['pname'];
	 //$branch=$_POST['branch'];
	 $email=$_POST['email'];
	 //$phone=$_POST['phone'];
	 $gender=$_POST['gender'];
	 //$dob=$_POST['dob'];
	 //$pphone=$_POST['pphone'];

    $sql = "SELECT * from user WHERE username LIKE '{$username}' AND password LIKE '{$password}'";
    $result = $mysqli->query($sql);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) // Validate email address
        {
            $message =  "Invalid email address please type a valid email!!";
        }
    if ($result->num_rows>0) {
        echo "<p>Username already exixts</p>";
    } else {
       echo "<p>Signup is done successfully</p>";
      $sql="insert into user(username,password,name,email,gender)values('".$username."','".$password."','".$name."','".$email."','".$gender."')";
    $result = $mysqli->query($sql);
        // $sqll="insert into curruser(regno)values('".$regno."')";
        // $result = $mysqli->query($sqll);
// $sql="insert into studetails(name,regno,year,branch,email,phone,gender,dob,pname,pphone) values('".$name."','".$regno."','".$year."','".$branch."','".$email."','".$phone."','".$gender."','".$dob."','".$pname."','".$pphone."')";
//   $result = $mysqli->query($sql);
 
	header('Location: index.php');
        // do stuffs
	
    }
}
?>      
</div>
   
    
    
 
 </body>
</html>
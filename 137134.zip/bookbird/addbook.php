<?php
	session_start();
	// check to see if user is logged in. If not, redirect to admin page
	if(!isset($_SESSION['admin'])) {
		header("Location:index.php?page=admin");
	}
?>
<h1>Add new Book</h1>
<form method="post" action="index.php?page=enterdocument2" />
<input list="cat" name="browser">
<datalist id="cat">



<?php

$cat_sql="SELECT cat_name FROM category";
			$cat_query=mysqli_query($dbconnect, $cat_sql);
			$cat_rs=mysqli_fetch_assoc($cat_query);
		
			do { ?>
			<option value="<?php echo $cat_rs['cat_name']; ?>" > </option>
				
				<?php
			} while ($cat_rs=mysqli_fetch_assoc($cat_query))

?>

</datalist>
<br><br>
 Name: <input type="text" name="name" >
   <br><br>
   Price: <input type="number" name="price">
   <br><br>
   cat_id: <input type="number" name="cat_id">
   <br><br>
   Thumbnail: <input type="text" name="thumbnail" >
   <br><br>
   Description: <textarea name="description" rows="5" cols="40"></textarea>
   <br><br>
<p><input type="submit" name="submit" value="Add Book" /></p>

</form>

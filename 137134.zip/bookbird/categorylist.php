
<?php

$cat_sql="SELECT * FROM category";
			$cat_query=mysqli_query($dbconnect, $cat_sql);
			$cat_rs=mysqli_fetch_assoc($cat_query);
		
			do { ?>
			<a href="index.php?page=category&cat_id=<?php echo $cat_rs['cat_id']; ?>"><?php echo $cat_rs['cat_name']; ?></a>
				
				<?php
			} while ($cat_rs=mysqli_fetch_assoc($cat_query))


?>

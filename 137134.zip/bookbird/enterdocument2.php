<?php
	session_start();
	// check to see if user is logged in. If not, redirect to admin page
	if(!isset($_SESSION['admin'])) {
		header("Location:index.php?page=admin");
	}
	
	// check to see if user has submitted the add category form
	if(!isset($_POST['submit'])) {
		header("Location:index.php?page=admin");
	}
	
	// enter the new category
	//INSERT INTO `books`.`category` (`cat_id`, `cat_name`) VALUES (NULL, 'test');
	$name = mysqli_real_escape_string($dbconnect, $_POST['name']);
	$cat_id = mysqli_real_escape_string($dbconnect, $_POST['cat_id']);
	$price = mysqli_real_escape_string($dbconnect, $_POST['price']);
	$thumbnail = mysqli_real_escape_string($dbconnect, $_POST['thumbnail']);
	$description = mysqli_real_escape_string($dbconnect, $_POST['description ']);
	$newbook_sql="INSERT INTO stock (name,cat_id,price,thumbnail,description)
	VALUES ('$name','$cat_id','$price','$thumbnail','$description')";




	//$newbook_sql = "INSERT INTO category (cat_name) VALUES ('".mysqli_real_escape_string($dbconnect,$_POST['name'])."')";
	//$newcategory_sql = " INSERT INTO category ('cat_id', 'cat_name') VALUES (NULL, 'test');"
	$newbook_qry = mysqli_query($dbconnect,$newbook_sql);
?>
<p>New book has been entered</p>
<p><a href="index.php?page=admin">Return to admin panel</a></p>